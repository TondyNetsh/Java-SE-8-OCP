package IO.question4;

import java.io.Console;

public class Quest4 {
    public static void main(String[] args) {
        Console c = System.console();
        String s = c.readLine();
    }
}
/*=========================================================================================
Which of the following can fill in the blank to make the code compile? (Choose all that
apply.)
A. c.input()
B. c.read()
C. c.readLine()
D. c.readPassword()
E. c.readString()
F. None of the above
============================================================================================
C. The readLine() method returns a String and reads a line of input from the console.
readPassword() returns a char[]. The others do not exist.
 */