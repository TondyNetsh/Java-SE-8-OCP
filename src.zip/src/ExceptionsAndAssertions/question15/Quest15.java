package ExceptionsAndAssertions.question15;

class One extends RuntimeException {}
class Two extends Exception {}
class Three extends Error {}
class Four extends One {}
class Five extends Two {}
class Six extends Three {}
public class Quest15 {
}
/*
Which of the following are checked exceptions? (Choose all that apply.)
A. One
B. Two
C. Three
D. Four
E. Five
F. Six

========================================================================
B, E. A checked exception extends Exception but not RuntimeException.
The entire hierarchy counts, so B and E are both correct.
 */