package ExceptionsAndAssertions.question8;

public class On {
    public static void main(String[] args) {
        String s = null;
        assert s != null;
    }
}
/*
Which of the following command lines cause this program to fail on the assertion? (Choose
all that apply.)
A. java –da On
B. java –ea On
C. java -da -ea:On On
D. java -ea -da:On On
E. The code does not compile.
=========================================================================================
B, C. Java uses the flags –ea or –enableassertions to turn on assertions. –da or
–disableassertions turns off assertions. The colon indicates for a specific class. Choice B
is correct because it turns on assertions for all code. Choice C is correct because it disables
assertions but then turns them back on for this class.
*/