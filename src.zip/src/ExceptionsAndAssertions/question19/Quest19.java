package ExceptionsAndAssertions.question19;

import java.io.IOException;
import java.sql.SQLException;

public class Quest19 {
    public void read() throws SQLException {
        try {
            readFromDatabase();
        } catch (SQLException | RuntimeException e) {
            throw e;
        }
    }
    private void readFromDatabase() throws SQLException {}
}
/*
Which of the following cannot fill in the blank? (Choose all that apply.)
A. Exception
B. RuntimeException
C. SQLException
D. SQLException | IOException
E. SQLException | RuntimeException
==========================================================================================
D. Choice A is allowed because Java 7 and later “translates” Exception in a catch block to
the correct one. Choices C and E are allowed because they actually catch a SQLException.
Choice D is not allowed because there is no IOException declared. Choice B is allowed
because a method does not have to handle an exception if it declares it.
 */