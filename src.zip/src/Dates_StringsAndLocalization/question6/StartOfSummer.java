package Dates_StringsAndLocalization.question6;

import java.time.LocalDate;

public class StartOfSummer {
    public static void main(String[] args) {
        LocalDate date = LocalDate.of(2014,6,21);

        System.out.println(date);
    }
}
