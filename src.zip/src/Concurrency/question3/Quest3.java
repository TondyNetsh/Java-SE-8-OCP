package Concurrency.question3;

import java.util.concurrent.*;

public class Quest3 {
    public static void main(String[] args) throws ExecutionException, InterruptedException {
        ExecutorService service = Executors.newSingleThreadScheduledExecutor();
        //service.scheduleWithFixedDelay(() -> {              // w1
        //            System.out.println("Open Zoo");
        //            return null;                            // w2
        //        }, 0,1, TimeUnit.MINUTES);
        Future<?> result = service.submit(() -> System.out.println("Wake Staff"));  // w3
        System.out.println(result.get());                   // w4
    }
}
/*
Which lines need to be changed to make the code compile? (Choose all that apply.)
A. It compiles and runs without issue.
B. Line w1
C. Line w2
D. Line w3
E. Line w4
F. It compiles but throws an exception at runtime.
=========================================================================================
B, C. The code does not compile, so A and F are incorrect. The first problem is that
although a ScheduledExecutorService is created, it is assigned to an ExecutorService.
Since scheduleWithFixedDelay() does not exist in ExecutorService, line w1 will not
compile, and B is correct. The second problem is that scheduleWithFixedDelay()supports
only Runnable, not Callable, and any attempt to return a value is invalid in a Runnable
lambda expression; therefore line w2 will also not compile and C is correct. The rest of the
lines compile without issue, so D and E are incorrect.
 */