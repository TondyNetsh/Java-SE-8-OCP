package AdvancedClassDesign.question11.my.sports;

public class Football {
    public static final int TEAM_SIZE = 11;
}
