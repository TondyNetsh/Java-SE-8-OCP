package AdvancedClassDesign.question11.my.apps;

import static AdvancedClassDesign.question11.my.sports.Football.*;

public class FootballGame {
    public int getTeamSize() {
        return TEAM_SIZE;
    }
}
