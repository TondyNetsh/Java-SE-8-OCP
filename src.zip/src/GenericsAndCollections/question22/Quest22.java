package GenericsAndCollections.question22;

public class Quest22 {
    public static<T> T identify(T t) {
        return t;
    }
}
